package com.employee.constants;

public class AutomationConstants {
	
	public static String expusername="practice.swtesting@gmail.com";
	public static String exppassword="123";
	public static String ExpTitle=":: ICT ACADEMY OF KERALA ::";
	public static String expname="Pooja Pushkaran";
	public static String exppwd="123";
	public static String expemail="Pooja@gmail.com";
	public static String expdesignation="HR";
	public static String expreporting="Demo";
	public static String expmember="HR";
	public static String expempid="51489";
	public static String expconfirmpwd="123";
	public static String expmobileno="9061194580";
	public static String expemptype="Temp";
	public static String expaddress="Pampady, kottayam";

}
